/*
	Minesweeper.js
	Author: Brian Glaz & Neil Brittliff
	
	Desccription:
		Javascript implementation of the classic game, Minesweeper	
*/

//Minesweeper constructor to represent the game
class Minesweeper {
    constructor(opts = {}) {
        let loadedData = {};

        //check if a game is saved in localStorage
        if (hasLocalStorage && localStorage["minesweeper.data"]) {
            loadedData = JSON.parse(localStorage["minesweeper.data"]);
            this.loadGame = true;
        }

        document.getElementById("new_game_button").innerHTML = "&#128512";

        Object.assign(
            this, {
                grid: [], //will hold an array of Cell objects
                minesFound: 0, //number of mines correctly flagged by user
                falseMines: 0, //number of mines incorrectly flagged
                status_msg: "Playing...", //game status msg, 'Won','Lost', or 'Playing'
                playing: true,
                movesMade: 0, //keep track of the number of moves
                options: {
                    rows: 8, //number of rows in the grid
                    cols: 8, //number of columns in the grid
                    mines: 10 //number of mines in the grid
                }
            }, { options: opts },
            loadedData
        );

        //validate options
        let rows = this.options["rows"];

        if (isNaN(rows)) {
            this.options["rows"] = 8;
        } else if (rows < 3) {
            this.options["rows"] = 3;
        } else if (rows > 19) {
            this.options["rows"] = 19;
        }

        let cols = this.options["cols"];

        if (isNaN(cols)) {
            this.options["cols"] = 8;
        } else if (cols < 3) {
            this.options["cols"] = 3;
        } else if (cols > 19) {
            this.options["cols"] = 19;
        }

        if (isNaN(this.options["mines"])) {
            this.options["mines"] = 10;
        }
        if (this.options["mines"] < 0) {
            this.options["mines"] = 1;
        } else if (
            this.options["mines"] >
            this.options["rows"] * this.options["cols"]
        ) {
            this.options["mines"] = this.options["rows"] * this.options["cols"];
        }

        if (this.loadGame) {
            this.load();
        } else {
            this.init();
        }
        this.save();
    }

    //setup the game grid
    init() {
        //populate the grid with cells
        for (let r = 0; r < this.options["rows"]; r++) {
            this.grid[r] = [];
            for (let c = 0; c < this.options["cols"]; c++) {
                this.grid[r].push(new Cell({ xpos: c, ypos: r }));
            }
        }

        //randomly assign mines
        let assignedMines = 0;
        while (assignedMines < this.options.mines) {
            var rowIndex = Math.floor(Math.random() * this.options.rows);
            var colIndex = Math.floor(Math.random() * this.options.cols);
            //assign and increment if cell is not already a mine
            let cell = this.grid[rowIndex][colIndex];
            if (!cell.isMine) {
                cell.isMine = true;
                cell.value = "M";
                assignedMines++;
            }
        }

        //update cell values, check for adjacent mines
        for (let r = 0; r < this.options["rows"]; r++) {
            for (let c = 0; c < this.options["cols"]; c++) {
                //no need to update mines
                if (!this.grid[r][c].isMine) {
                    let mineCount = 0,
                        adjCells = this.getAdjacentCells(r, c);
                    for (let i = adjCells.length; i--;) {
                        if (adjCells[i].isMine) {
                            mineCount++;
                        }
                    }

                    this.grid[r][c].value = mineCount;
                }
            }
        }
        this.render();
    }

    //populate the grid from loaded data - need to create cell objects from raw data
    load() {
        for (let r = 0, r_len = this.grid.length; r < r_len; r++) {
            for (let c = 0, c_len = this.grid[r].length; c < c_len; c++) {
                this.grid[r][c] = new Cell(this.grid[r][c]);
            }
        }

        this.render();
    }

    //construct the DOM representing the grid
    render() {
        const gameContainer = document.getElementById("game_container");

        //clear old DOM
        gameContainer.innerHTML = "";
        let width = 35;
        let height = 32;
        let fontsize = 19;
        let padding = "10px 5px 5px 5px";

        if (this.options.cols <= 8 && this.options.rows <= 8) {
            padding = "18px 9px 9px 9px";
            height = 34;
            width = 39;
            fontsize = 20;
        } else if (this.options.cols <= 12 && this.options.rows <= 12) {
            height = 25;
            width = 35;
            fontsize = 14;
        } else {
            let padding = "4px 1px 1px 1px";
            height = 16;
            width = 18;
            fontsize = 10;
        }

        let content = "";
        for (let r = 0; r < this.options.rows; r++) {
            content += '<div class="row">';
            for (let c = 0; c < this.options.cols; c++) {
                let cellObj = this.grid[r][c];

                //assign proper text and class to cells (needed when loading a game)
                let add_class = "",
                    txt = "";
                if (cellObj.isFlagged) {
                    add_class = "flagged";
                } else if (cellObj.isRevealed) {
                    add_class = `revealed adj-${cellObj.value}`;
                    txt = (!cellObj.isMine ? cellObj.value || "" : "");
                };

                content += `<div class="cell ${add_class}" style="width:${width}px; height:${height}px; font-size:${fontsize}px; padding:${padding};" data-xpos="${c}" data-ypos="${r}">${txt}</div>`;
            }
            content += "</div>";
        }

        gameContainer.innerHTML = content;

        //update input fields
        document.getElementById("new_rows").value = this.options["rows"];
        document.getElementById("new_cols").value = this.options["cols"];
        document.getElementById("new_mines").value = this.options["mines"];

        //setup status message
        document.getElementById("mine_count").textContent =
            this.options["mines"] - (this.falseMines + this.minesFound);
        document.getElementById("moves_made").textContent = this.movesMade;
        document.getElementById("game_status").textContent = this.status_msg;
        document.getElementById("game_status").style.color = "black";
    }

    //returns an array of cells adjacent to the row,col passed in
    getAdjacentCells(row, col) {
        let results = [];
        for (
            let rowPos = row > 0 ? -1 : 0; rowPos <= (row < this.options.rows - 1 ? 1 : 0); rowPos++
        ) {
            for (
                let colPos = col > 0 ? -1 : 0; colPos <= (col < this.options.cols - 1 ? 1 : 0); colPos++
            ) {
                results.push(this.grid[row + rowPos][col + colPos]);
            }
        }
        return results;
    }

    //reveal a cell
    revealCell(cell) {
        if (!cell.isRevealed && !cell.isFlagged && this.playing) {
            const cellElement = cell.getElement();

            cell.isRevealed = true;
            cellElement.classList.add("revealed", `adj-${cell.value}`);
            cellElement.textContent = (!cell.isMine ? cell.value || "" : "");

            //end the game if user clicked a mine
            if (cell.isMine) {
                this.status_msg = "Sorry, you lost!";
                this.playing = false;
                document.getElementById("game_status").textContent = this.status_msg;
                document.getElementById("game_status").style.color = "#EE0000";
                document.getElementById("new_game_button").innerHTML = "&#128534;";

                // You could be a winner
            } else if (!cell.isFlagged && cell.value == 0) {

                //if the clicked cell has 0 adjacent mines, we need to recurse to clear out all adjacent 0 cells
                const adjCells = this.getAdjacentCells(cell.ypos, cell.xpos);
                for (let iCell = 0, len = adjCells.length; iCell < len; iCell++) {
                    this.revealCell(adjCells[iCell]);
                }

            }

        }

    }

    //flag a cell
    flagCell(cell) {

        if (!cell.isRevealed && this.playing) {
            const cellElement = cell.getElement(),
                mineCount = document.getElementById("mine_count");

            if (!cell.isFlagged) {
                cell.isFlagged = true;
                cellElement.classList.add("flagged");
                mineCount.textContent = parseFloat(mineCount.textContent) - 1;
                if (cell.isMine) {
                    this.minesFound++;
                } else {
                    this.falseMines++;
                }
            } else {
                cell.isFlagged = false;
                cellElement.classList.remove("flagged");
                cellElement.textContent = "";
                mineCount.textContent = parseFloat(mineCount.textContent) + 1;
                if (cell.isMine) {
                    this.minesFound--;
                } else {
                    this.falseMines--;
                };

            }

        }

        if (this.minesFound === this.options.mines && this.falseMines === 0) {
            this.status_msg = "You won!!";
            this.playing = false;
            document.getElementById("game_status").textContent = this.status_msg;
            document.getElementById("game_status").style.color = "#00FF00";

            document.getElementById("new_game_button").innerHTML = "&#128526;";

        }

    }

    //debgugging function to print the grid to console
    gridToString() {
        let result = "";
        for (let r = 0, r_len = this.grid.length; r < r_len; r++) {
            for (let c = 0, c_len = this.grid[r].length; c < c_len; c++) {
                result += this.grid[r][c].value + " ";
            }
            result += "\n";
        }
        return result;
    }

    //save the game object to localstorage
    save() {
        if (!hasLocalStorage) {
            return false;
        } else {
            let data = JSON.stringify(this);
            localStorage["minesweeper.data"] = data;
        }
    }
}

//Cell constructor to represent a cell object in the grid
class Cell {
    constructor({
        xpos,
        ypos,
        value = 0,
        isMine = false,
        isRevealed = false,
        isFlagged = false
    }) {
        Object.assign(this, {
            xpos,
            ypos,
            value, //value of a cell: number of adjacent mines, F for flagged, M for mine
            isMine,
            isRevealed,
            isFlagged
        });
    }

    getElement() {
        return document.querySelector(
            `.cell[data-xpos="${this.xpos}"][data-ypos="${this.ypos}"]`
        );
    }
}

//create a new game
function newGame(opts = {}) {
    game = new Minesweeper(opts);
}

window.onload = function() {
    //attack click to new game button
    document
        .getElementById("new_game_button")
        .addEventListener("click", function() {
            const opts = {
                rows: parseInt(document.getElementById("new_rows").value, 10),
                cols: parseInt(document.getElementById("new_cols").value, 10),
                mines: parseInt(document.getElementById("new_mines").value, 10)
            };

            if (hasLocalStorage) {
                localStorage.clear();
            }

            newGame(opts);
        });


    //attach click event to cells - left click to reveal
    document
        .getElementById("game_container")
        .addEventListener("mousedown", function(e) {

            if (!game.playing) {
                return;
            }

            if (e.button == 0) {
                document.getElementById("new_game_button").innerHTML = "&#128562;";
            }
            if (e.button == 2) {
                document.getElementById("new_game_button").innerHTML = "&#128556;";
            }

        });

    //attach click event to cells - left click to reveal
    document
        .getElementById("game_container")
        .addEventListener("mouseup", function(e) {

            if (!game.playing) {
                return;
            }

            document.getElementById("new_game_button").innerHTML = "&#128512;";

            if (e.button == 0) {
                const target = e.target;

                if (target.classList.contains("cell")) {
                    const cell =
                        game.grid[target.getAttribute("data-ypos")][
                            target.getAttribute("data-xpos")
                        ];

                    if (!cell.isRevealed && game.playing) {
                        game.movesMade++;
                        document.getElementById("moves_made").textContent = game.movesMade;
                        game.revealCell(cell);
                        game.save();
                    }
                }

            } else if (e.button == 2) {
                const target = e.target;

                if (target.classList.contains("cell")) {
                    const cell =
                        game.grid[target.getAttribute("data-ypos")][
                            target.getAttribute("data-xpos")
                        ];
                    if (!cell.isRevealed && game.playing) {
                        game.movesMade++;
                        document.getElementById("moves_made").textContent = game.movesMade;
                        game.flagCell(cell);
                        game.save();
                    }
                }
            }

        });

    //create a game
    newGame();

};

//global vars

var game;

//check support for local storage: credit - http://diveintohtml5.info/storage.html
const hasLocalStorage = (function() {
    try {
        return "localStorage" in window && window["localStorage"] !== null;
    } catch (e) {
        return false;
    }
})();