Daleks.Sound = (function() {

    function Sound(src) {
        this.audio = new Audio($(src)[0].src);
    }

    Sound.prototype = {
        volume: function(volume) {
            this.audio.volume = 0.2
        },

        play: function() {
            this.audio.play()
        },

        volume: function(adjust) {
            this.audio.volume = adjust;
        }

    }

    return Sound;

})();